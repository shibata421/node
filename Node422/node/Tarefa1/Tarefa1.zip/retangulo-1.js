const perimeter = (x, y) => (2 * (Number(x) + Number(y)));
const area = (x, y) => (Number(x) * Number(y));

module.exports = { perimeter, area }