const express = require('express');
const app = express();
const mysql = require('mysql');
const axios = require('axios');


async function insertCep(data) {
    const con = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "Senhadomysql1",
      database: "db_ceps"
    });
    
    await con.connect((err) => {
        if (err) throw err;
        let sql = "INSERT INTO ceps (cep, logradouro, complemento, bairro, localidade, uf, ibge, gia, ddd, siafi) VALUES ?"
        let values = [
            [data.cep, data.logradouro, data.complemento, data.bairro, data.localidade, data.uf, data.ibge, data.gia, data.ddd, data.siafi]
        ]
        con.query(sql, [values], (err, result) => {
            if (err) throw err;
            console.log('gravado com sucesso!');
        });
        con.end();
    })
}
app.get('/',function(req,response){
    response.sendFile(__dirname+'/index.html')
})
app.get('/get-cep', (request, resp) => {
    console.log(`CEP Recebido: ${request.query.cep}`);
	axios.get(`https://viacep.com.br/ws/${request.query.cep}/json/`)
	     .then(response => {
            console.log(response.data); 
            insertCep(response.data).then(result => {
                resp.send('Sucesso!')
            }).catch(err => resp.send('Erro!') );
        })
         .catch(err => {console.log(`Error: ${err}`)});
});
const port = 8080;
app.listen(port, () => {
    console.log(`app is listening on port ${port}`)
})