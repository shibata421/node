module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "Senhadomysql1",
  DB: "test"
};